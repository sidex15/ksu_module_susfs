# default values
hide_cusrom=0
hide_gapps=0
hide_revanced=1
spoof_cmdline=0
hide_loops=1

